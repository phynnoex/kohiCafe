import MenuSection from "../../layout/menuSection";

export default function Menu() {
  return <MenuSection />;
}
