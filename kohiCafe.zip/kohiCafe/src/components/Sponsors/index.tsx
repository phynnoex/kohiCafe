import "./styles.scss"

export default function Sponsors() {
    return(
        <div className="sponsorsContainer">
        </div>
    )
}